page('/', articlesController.index);
page('/about', aboutController.index);

page();

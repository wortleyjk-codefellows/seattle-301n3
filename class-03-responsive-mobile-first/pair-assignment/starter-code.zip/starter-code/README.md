# Static MVC Blog

This is a simple blogging system front end. The code is organized with MVC principles in mind.

It starts small, but will be gaining new features regularly. 
